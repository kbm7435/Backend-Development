var express = require('express');
var app = express();
var http = require('http');
var fs = require('fs');
var url = require('url');
var datalayer = require('./companydata/index.js');
var dl = new datalayer("kbm7435");
const port = 8080;
var Department = require('./companydata/lib/department');
var Employee = require('./companydata/lib/employee');
var TIMECARD = require('./companydata/lib/timecard');
var urlencodedParser = express.urlencoded({extended:false});
var validator = require('./bizz.js');

const hostname = "CompanyServices";


////////////////// DEPARTMENTS //////////////////////////

//get department 
app.get(`/${hostname}/department`,function(req,res){
    if (validator.checkCompanyName(req.query.company)){
        res.json({error:validator.checkCompanyName(req.query.company)});
    }
    var dep = dl.getDepartment(req.query.company,req.query.dept_id);
    res.send(JSON.stringify(dep));
});

// get all departments
app.get(`/${hostname}/departments`,function(req,res){
    
    var dep = dl.getAllDepartment(req.query.company);

    res.send(JSON.stringify(dep));
    console.log(dep);
    
});

// add an department
app.post(`/${hostname}/department`,urlencodedParser,function(req,res){
    if (validator.checkCompanyName(req.body.company)){
        res.json({error:validator.checkCompanyName(req.body.company)});
    }

    
    var newDepartment = new Department(
        req.body.company,
        req.body.dept_name,
        req.body.dept_no,
        req.body.location);

    var dep = dl.insertDepartment(newDepartment);

    var message = {success: dep};
    res.send(JSON.stringify(message));
    
    try {
        return res.json(message);
        
    } catch (error) {
        console.log(error);
        return {error:"Error in insert department"};
    }


});

//Update Department 
app.put(`/${hostname}/department`,urlencodedParser, function(req, res){
    if (validator.checkCompanyName(req.body.company)){
        res.json({error:validator.checkCompanyName(req.body.company)});
    }


    let ogDept = dl.getDepartment(req.body.company, req.body.dept_id);
    
    let dept_name = req.body.dept_name;
    let dept_no = req.body.dept_no;
    let location = req.body.location;
    

    if(dept_name == null){
        dept_name = ogDept.dept_name;
    }

    if(dept_no == null){
        dept_no = ogDept.dept_no;
    }

    if(location == null){
        location = ogDept.location;
    }
    let department = new Department (
                                    req.body.company,
                                    dept_name,
                                    dept_no,
                                    location,
                                    req.body.dept_id);


    try{
        var dept = dl.updateDepartment(department);
        var response = {success:{dept_id:dept.dept_id,
                            company:dept.company,
                            dept_name:dept.dept_name,
                            dept_no:dept.dept_no,
                            location:dept.location}};
        var errorMessage = {error: "Issue---- Cannot PUT department"};

    }catch{
        console.log(err);
        return {error: "Error in PUT try-catch"};
    }
    if(dept == null){
        return res.send(errorMessage);
    }else{
        return res.send(JSON.stringify(response));
    }


});



// delete an department
app.delete(`/${hostname}/department`,function(req,res){
    if (validator.checkCompanyName(req.query.company)){
        res.json({error:validator.checkCompanyName(req.query.company)});
    }

    dl.deleteDepartment(req.query.company,req.query.dept_id);
    var message = {success:req.query.company};
    res.send(JSON.stringify(message));


});


//////// COMPANY ///////////////

// delete a company 
app.delete(`/${hostname}/company`,function(req,res){
    if (validator.checkCompanyName(req.query.company)){
        res.json({error:validator.checkCompanyName(req.query.company)});
    }

    dl.deleteCompany(req.query.company);
    var message = {success:req.query.company};
    res.send(JSON.stringify(message));
});





////////// EMPLOYEES ///////////////////

// GET A EMPLOYEE
app.get(`/${hostname}/employee`,function(req,res){
    if (validator.checkCompanyName(req.query.company)){
        res.json({error:validator.checkCompanyName(req.query.company)});
    }
    var emp = dl.getEmployee(req.query.emp_id);

    try {
        return res.json(emp);
    } catch (error) {
        console.log(error);
    }
});

// GET ALL EMPLOYEES
app.get(`/${hostname}/employees`,function(req,res){
    if (validator.checkCompanyName(req.query.company)){
    res.json({error:validator.checkCompanyName(req.query.company)});
    }
    
    var emp = dl.getAllEmployee(req.query.company);

    
    try {
        return res.json(emp);
    } catch (error) {
        console.log(error);
        return {error: "Error in get employees"};
    }
});

// ADD AN EMPLOYEE
app.post(`/${hostname}/employee`,urlencodedParser,function(req,res){
    if (validator.checkCompanyName(req.body.company)){
        res.json({error:validator.checkCompanyName(req.body.company)});
    }

    var emp = new dl.Employee(req.body.emp_name,req.body.emp_no,req.body.hire_date,req.body.job,req.body.salary,req.body.dept_id,req.body.mng_id);

    dl.insertEmployee(emp);
    console.log(emp);

    var message = {success:{emp_id:req.body.emp_id,emp_name:req.body.emp_name,emp_no:req.body.emp_no,hire_date:req.body.hire_date,job:req.body.job,salary:req.body.salary,dept_id:req.body.dept_id,mng_id:req.body.mng_id}};
    

    try {
        return res.json(message);
        
    } catch (error) {
        console.log(error);
        return {error:"ERROR IN INSERT FOR EMPLOYEE"};
    }
});

// UPDATE AN EMPLOYEE 
app.put(`/${hostname}/employee`,urlencodedParser, function(req, res){
    if (validator.checkCompanyName(req.body.company)){
        res.json({error:validator.checkCompanyName(req.body.company)});
    }
    let emp_id = req.body.emp_id;
    let ogemp = dl.getEmployee(emp_id);
    console.log(ogemp);

    let emp_name = req.body.emp_name != null ? req.body.emp_name : ogemp.emp_name;
    let emp_no = req.body.emp_no != null ? req.body.emp_no : ogemp.emp_no;
    let hire_date = req.body.hire_date != null ? req.body.hire_date : ogemp.hire_date;
    let job = req.body.job != null ? req.body.job : ogemp.job;
    let salary = req.body.salary != null ? req.body.salary : ogemp.salary;
    let dept_id = req.body.dept_id != null ? req.body.dept_id : ogemp.dept_id;
    let mng_id = req.body.mng_id != null ? req.body.mng_id : ogemp.mng_id;
    let employee = new Employee (
                                    emp_name,
                                    emp_no,
                                    job,
                                    hire_date,
                                    salary,
                                    dept_id,
                                    mng_id,
                                    emp_id);

                                  
    try{
        console.log(employee);
       var emp = dl.updateEmployee(employee);
        var response = {success:{emp_name:emp.emp_name,
                                emp_no:emp.emp_no,
                                hire_date:emp.hire_date,
                                job:emp.job,
                                salary:emp.salary,
                                dept_id:emp.dept_id,
                                mng_id:emp.mng_id,
                                emp_id:emp.emp_id}};
        var errorMsg = {error: "Couldn't PUT employee"};
        
    }catch(err){
        console.log(err);
        return {error: "ERROR IN UPDATE EMPLOYEEE"};

    }
    if(emp == null){
        return res.send(errorMsg);

    }else{
        return res.send(JSON.stringify(response));

    }
});





// delete an employee
app.delete(`/${hostname}/employee`,function(req,res){
    if (validator.checkCompanyName(req.query.company)){
        res.json({error:validator.checkCompanyName(req.query.company)});
    }
console.log(req.query.emp_id);
    let response = dl.deleteEmployee(req.query.emp_id);
    var message = {success:response};
    res.send(JSON.stringify(message));
});




////// TIMECARD /////////////////


// get timecard 
app.get(`/${hostname}/timecard`,function(req,res){
    if (validator.checkCompanyName(req.query.company)){
        res.json({error:validator.checkCompanyName(req.query.company)});
    }
    var timecard = dl.getTimecard(req.query.timecard_id);
    var errorMsg = {error: "There isn't a timecard!!!!"};
    try{
        
        if(timecard == null){
            return res.send(errorMsg);
        }else{
            return res.send(JSON.stringify(timecard));
        }

    }catch{
        console.log(err);
        return {error: "ERROR IN GET TIMECARD"};
    }

});



// get all timecards
app.get(`/${hostname}/timecards`,function(req,res){
    if (validator.checkCompanyName(req.query.company)){
        res.json({error:validator.checkCompanyName(req.query.company)});
    }
    var timecard = dl.getAllTimecard(req.query.emp_id);

    try {
        return res.json(timecard);
    } catch (error) {
        console.log(error);
        return {error: "ERROR IN GET ALL TIMECARDS!"};
    }
});


// insert timecard 
app.post(`/${hostname}/timecard`,urlencodedParser,function(req,res){
    if (validator.checkCompanyName(req.body.company)){
        res.json({error:validator.checkCompanyName(req.body.company)});
    }
    var timecard = new dl.Timecard(req.body.start_time,req.body.end_time,req.body.emp_id,req.body.timecard_id);
    dl.insertTimecard(timecard);
    var message = {success:{timecard_id:req.body.timecard_id,start_time:req.body.start_time,end_time:req.body.end_time,emp_id:req.body.emp_id}};

    try {
        return res.json(message);
        
    } catch (error) {
        console.log(error);
        return {error:"ERROR IN INSERTING TIMECARD"};
    }
});

// update timecard
app.put(`/${hostname}/timecard`,urlencodedParser, function(req, res){
    if (validator.checkCompanyName(req.body.company)){
        res.json({error:validator.checkCompanyName(req.body.company)});
    }


    dl.getTimecard(req.body.timecard_id);
    let timecard = new TIMECARD(req.body.start_time,req.body.end_time,req.body.emp_id,req.body.timecard_id);

    try{
        dl.updateTimecard(timecard);
        var message = {success:{timecard_id:req.body.timecard_id,start_time:req.body.start_time,end_time:req.body.end_time,emp_id:req.body.emp_id}};
        return res.json(message);
    }catch(error){
        console.log(error);
        return {error: "Error in update timecard"};
    }
});

//delete timecard
app.delete(`/${hostname}/timecard`,function(req,res){
    if (validator.checkCompanyName(req.query.company)){
        res.json({error:validator.checkCompanyName(req.query.company)});
    }
    dl.deleteTimecard(req.query.timecard_id);
    var message = {success:'Timecard ' + req.query.timecard_id + ' has been deleted'};

    try {
        return res.json(message);
    } catch (error) {
        console.log(error);
        return {error: "ERROR IN DELETING TIMECARD"};
    }
    
});




app.listen(port, console.log(`Router listening for input on port: ${port}`));
module.exports = app;